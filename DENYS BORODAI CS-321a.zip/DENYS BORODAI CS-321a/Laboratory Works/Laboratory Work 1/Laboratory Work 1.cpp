﻿#include "Header.h"



int main()
{
  
	srand(time(NULL));


	Main main;
	main.main();
	









}


