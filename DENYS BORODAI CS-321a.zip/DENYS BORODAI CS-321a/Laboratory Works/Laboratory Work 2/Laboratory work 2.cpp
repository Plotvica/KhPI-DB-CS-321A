﻿#include "Header.h"

int main() { Main main; main.main(); }


