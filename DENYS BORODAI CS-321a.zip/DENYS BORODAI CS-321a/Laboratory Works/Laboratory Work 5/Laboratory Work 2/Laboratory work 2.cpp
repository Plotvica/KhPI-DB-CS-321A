﻿#include "Oper.h"

int main() { complite(); }


