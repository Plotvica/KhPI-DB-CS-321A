﻿#include <func.h>
int main() { complite(); }