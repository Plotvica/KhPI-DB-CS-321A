﻿#include "Header.h"


int main()
{
   
	Figure obj(5,5);
	
	obj = Figure(5,5,5);
	



}


