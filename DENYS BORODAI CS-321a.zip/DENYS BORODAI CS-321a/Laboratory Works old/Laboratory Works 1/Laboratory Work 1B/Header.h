#pragma once


#include <iostream>

using namespace std;

constexpr float PI = 3.14;

class Figure {

	float a, b, c, r;


public:

	Figure(const float& a = 0, const float& b = 0, const float& c = 0, const float& r = 0);

};