﻿#include "Header.h"





int main()
{
	srand(time(NULL));

	MASTER human[2] = { MASTER(4), MASTER()};
	human[0].show();
	human[1].show();

	cout << "\n\n\n\n";
	 
	
	


}


